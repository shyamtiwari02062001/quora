const Data = [
  {
    name: "Shyam Tiwari",
    designation: "Software engineer, Youtuber, Fitness enthusiast. Aug 8",
    question: `Why are people still joining TCS, Infosys, Wipro, Accenture and
 several other IT companies or any other private companies when they
 have understood that even a tea stall owner or Ola drivers earn more
 than them?`,
    answer: `I belong to a low income family, my father is small farmer.

 I used to think exactly the same when I joined my first company in 2013 with 15k salary. (Assume Ola driver started with income= 50K)
 
 I worked very hard I was not happy at all with my salary but I was helpless. But latter I found a close friend and mentor in my team who changed my view. I started working on my skills, completed java programmer certification.
 
 After 6months I got first salary hike 21k.
 
 After 1 year completion I was offered permanent role with 30k salary. (Assume Ola driver income= 55K)
 
 After completion of 2 years I started looking for job change and I got 2 job offers from reputed MNCs with 60k salary.(Assume Ola driver income= 60K)
 
 After that I kept learning new skills and looking for better job opportunities every 1–2 years.
 
 Now in 2022 my current Salary is 2 lakh per month. (Assume Ola driver income= 80K)
 
 Since child hood I experienced such a tough financial conditions I respect money and spend it very carefully. My monthly expense is only 10k and rest of the money goes to investments. From last 2 years I have been living with my family at my farm. Till now I only invested my money in creating extra income sources:
 
 1. Purchased new farm land and constructed a large Farm Pond for water storage, fish farming and planted thousands of trees like coconuts, sweet lime, mango, papaya at our farm.`,
  },
  {
    name: "Shyam Tiwari",
    designation: "Software engineer, Youtuber, Fitness enthusiast. Aug 8",
    question: `Why are people still joining TCS, Infosys, Wipro, Accenture and
 several other IT companies or any other private companies when they
 have understood that even a tea stall owner or Ola drivers earn more
 than them?`,
    answer: `I belong to a low income family, my father is small farmer.

 I used to think exactly the same when I joined my first company in 2013 with 15k salary. (Assume Ola driver started with income= 50K)
 
 I worked very hard I was not happy at all with my salary but I was helpless. But latter I found a close friend and mentor in my team who changed my view. I started working on my skills, completed java programmer certification.
 
 After 6months I got first salary hike 21k.
 
 After 1 year completion I was offered permanent role with 30k salary. (Assume Ola driver income= 55K)
 
 After completion of 2 years I started looking for job change and I got 2 job offers from reputed MNCs with 60k salary.(Assume Ola driver income= 60K)
 
 After that I kept learning new skills and looking for better job opportunities every 1–2 years.
 
 Now in 2022 my current Salary is 2 lakh per month. (Assume Ola driver income= 80K)
 
 Since child hood I experienced such a tough financial conditions I respect money and spend it very carefully. My monthly expense is only 10k and rest of the money goes to investments. From last 2 years I have been living with my family at my farm. Till now I only invested my money in creating extra income sources:
 
 1. Purchased new farm land and constructed a large Farm Pond for water storage, fish farming and planted thousands of trees like coconuts, sweet lime, mango, papaya at our farm.`,
  },
  {
    name: "Shyam Tiwari",
    designation: "Software engineer, Youtuber, Fitness enthusiast. Aug 8",
    question: `Why are people still joining TCS, Infosys, Wipro, Accenture and
 several other IT companies or any other private companies when they
 have understood that even a tea stall owner or Ola drivers earn more
 than them?`,
    answer: `I belong to a low income family, my father is small farmer.

 I used to think exactly the same when I joined my first company in 2013 with 15k salary. (Assume Ola driver started with income= 50K)
 
 I worked very hard I was not happy at all with my salary but I was helpless. But latter I found a close friend and mentor in my team who changed my view. I started working on my skills, completed java programmer certification.
 
 After 6months I got first salary hike 21k.
 
 After 1 year completion I was offered permanent role with 30k salary. (Assume Ola driver income= 55K)
 
 After completion of 2 years I started looking for job change and I got 2 job offers from reputed MNCs with 60k salary.(Assume Ola driver income= 60K)
 
 After that I kept learning new skills and looking for better job opportunities every 1–2 years.
 
 Now in 2022 my current Salary is 2 lakh per month. (Assume Ola driver income= 80K)
 
 Since child hood I experienced such a tough financial conditions I respect money and spend it very carefully. My monthly expense is only 10k and rest of the money goes to investments. From last 2 years I have been living with my family at my farm. Till now I only invested my money in creating extra income sources:
 
 1. Purchased new farm land and constructed a large Farm Pond for water storage, fish farming and planted thousands of trees like coconuts, sweet lime, mango, papaya at our farm.`,
  },
  {
    name: "Shyam Tiwari",
    designation: "Software engineer, Youtuber, Fitness enthusiast. Aug 8",
    question: `Why are people still joining TCS, Infosys, Wipro, Accenture and
 several other IT companies or any other private companies when they
 have understood that even a tea stall owner or Ola drivers earn more
 than them?`,
    answer: `I belong to a low income family, my father is small farmer.

 I used to think exactly the same when I joined my first company in 2013 with 15k salary. (Assume Ola driver started with income= 50K)
 
 I worked very hard I was not happy at all with my salary but I was helpless. But latter I found a close friend and mentor in my team who changed my view. I started working on my skills, completed java programmer certification.
 
 After 6months I got first salary hike 21k.
 
 After 1 year completion I was offered permanent role with 30k salary. (Assume Ola driver income= 55K)
 
 After completion of 2 years I started looking for job change and I got 2 job offers from reputed MNCs with 60k salary.(Assume Ola driver income= 60K)
 
 After that I kept learning new skills and looking for better job opportunities every 1–2 years.
 
 Now in 2022 my current Salary is 2 lakh per month. (Assume Ola driver income= 80K)
 
 Since child hood I experienced such a tough financial conditions I respect money and spend it very carefully. My monthly expense is only 10k and rest of the money goes to investments. From last 2 years I have been living with my family at my farm. Till now I only invested my money in creating extra income sources:
 
 1. Purchased new farm land and constructed a large Farm Pond for water storage, fish farming and planted thousands of trees like coconuts, sweet lime, mango, papaya at our farm.`,
  },
  {
    name: "Shyam Tiwari",
    designation: "Software engineer, Youtuber, Fitness enthusiast. Aug 8",
    question: `Why are people still joining TCS, Infosys, Wipro, Accenture and
 several other IT companies or any other private companies when they
 have understood that even a tea stall owner or Ola drivers earn more
 than them?`,
    answer: `I belong to a low income family, my father is small farmer.

 I used to think exactly the same when I joined my first company in 2013 with 15k salary. (Assume Ola driver started with income= 50K)
 
 I worked very hard I was not happy at all with my salary but I was helpless. But latter I found a close friend and mentor in my team who changed my view. I started working on my skills, completed java programmer certification.
 
 After 6months I got first salary hike 21k.
 
 After 1 year completion I was offered permanent role with 30k salary. (Assume Ola driver income= 55K)
 
 After completion of 2 years I started looking for job change and I got 2 job offers from reputed MNCs with 60k salary.(Assume Ola driver income= 60K)
 
 After that I kept learning new skills and looking for better job opportunities every 1–2 years.
 
 Now in 2022 my current Salary is 2 lakh per month. (Assume Ola driver income= 80K)
 
 Since child hood I experienced such a tough financial conditions I respect money and spend it very carefully. My monthly expense is only 10k and rest of the money goes to investments. From last 2 years I have been living with my family at my farm. Till now I only invested my money in creating extra income sources:
 
 1. Purchased new farm land and constructed a large Farm Pond for water storage, fish farming and planted thousands of trees like coconuts, sweet lime, mango, papaya at our farm.`,
  },
];
export default Data;
